<a href="index.php" class="brand-link">
      <img src="../img/logo.png" alt="Wejea Trans Logo" class="brand-image" style="opacity: .8">
      <span class="brand-text font-weight-light">Wejea Trans</span>
    </a>