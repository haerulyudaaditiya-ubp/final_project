<section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row" id="report"> </div>
        <!-- /.row -->
        <!-- Main row -->
        <!-- <div class="row" id="donutChart"> </div> -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-7 connectedSortable">
            <!-- Card untuk menampilkan beberapa informasi -->
            <div class="card" id="statistik_penyewaan"> </div>
          </section>
          <!-- /.Left col --
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>